package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {




    TextView textView;
    @Override
    public void onStart()
    {
            super.onStart();
            if(FirebaseAuth.getInstance().getCurrentUser()!=null)
            {
                startActivity(new Intent(getApplicationContext(),Main6Activity.class));
finish();            }


    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);


        textView=(TextView)findViewById(R.id.text_View1);
        textView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent= new Intent(MainActivity.this,Main4Activity.class);
                startActivity(intent);
            }



        });

        textView=(TextView)findViewById(R.id.text_View2);
        textView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent= new Intent(MainActivity.this,Main5Activity.class);
                startActivity(intent);
            }



        });




    }
}
